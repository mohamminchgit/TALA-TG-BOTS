# Deployment Infrastructure Capability - Session Validation Delta

## ADDED Requirements

### Requirement: Pre-Deployment Session Validation
The deployment script SHALL validate the existence of all required Telegram session files on the target server before executing `docker compose up`.

#### Scenario: All required sessions present
- **GIVEN** deployment script is executed
- **AND** all required session files exist on the target server
- **WHEN** pre-deployment validation runs
- **THEN** validation SHALL pass
- **AND** deployment SHALL proceed to `docker compose up`

#### Scenario: Missing session file blocks deployment
- **GIVEN** deployment script is executed
- **AND** at least one required session file is missing on the target server
- **WHEN** pre-deployment validation runs
- **THEN** validation SHALL fail
- **AND** deployment SHALL abort with exit code 1
- **AND** error message SHALL list all missing session files
- **AND** error message SHALL include instructions: "Run 'python scripts/generate_session.py' on the server to create missing sessions."
- **AND** `docker compose up` SHALL NOT be executed

#### Scenario: Session validation reports file details
- **GIVEN** deployment script is executed
- **WHEN** pre-deployment validation runs
- **THEN** the script SHALL log the size and last modified timestamp of each session file
- **AND** if any file is older than 90 days, a warning SHALL be displayed

### Requirement: Session File Exclusion from Git
The repository SHALL include `.gitignore` rules to prevent session files from being committed.

#### Scenario: Session files ignored by Git
- **GIVEN** `.gitignore` contains `sessions/*.session` and `sessions/*.session-journal`
- **WHEN** `git status` is executed
- **THEN** no files matching `sessions/*.session*` SHALL appear in the output

#### Scenario: Accidental session commit is prevented
- **GIVEN** a developer attempts to `git add sessions/`
- **WHEN** Git processes the command
- **THEN** session files SHALL be excluded from staging
- **AND** only non-ignored files (e.g., README) SHALL be staged

### Requirement: Docker Volume Mount for Sessions
The deployment infrastructure SHALL mount the `sessions/` directory from the host to containers as a read-only volume.

#### Scenario: Session directory mounted as read-only
- **GIVEN** `docker-compose.yml` includes `- ./sessions:/app/sessions:ro`
- **WHEN** containers start
- **THEN** session files SHALL be readable by the application
- **AND** containers SHALL NOT be able to write to `/app/sessions`

#### Scenario: Missing sessions directory on host causes startup failure
- **GIVEN** `sessions/` directory does not exist on the host
- **WHEN** `docker compose up` is executed
- **THEN** Docker SHALL fail to start the containers
- **AND** error message SHALL indicate missing mount source

### Requirement: Container Pre-Flight Session Check
The Docker entrypoint script SHALL verify that all required session files are mounted and readable before starting application processes.

#### Scenario: Entrypoint validates sessions before startup
- **GIVEN** container is starting
- **AND** required session files are defined in environment variables
- **WHEN** entrypoint script runs
- **THEN** the script SHALL check existence of each required session file
- **AND** if all exist, the script SHALL proceed to start application processes
- **AND** if any are missing, the script SHALL log an error and exit with code 1

#### Scenario: Entrypoint lists available sessions on startup
- **GIVEN** container is starting
- **WHEN** entrypoint pre-flight check runs
- **THEN** the script SHALL log: "Found sessions: source.session, destination.session"
- **AND** the log level SHALL be INFO

### Requirement: Session Backup Recommendation
The deployment script SHALL display a reminder to back up session files before deploying.

#### Scenario: Deployment script reminds user to backup
- **GIVEN** deployment script is executed
- **WHEN** the script begins
- **THEN** a warning message SHALL be displayed: "REMINDER: Ensure session files are backed up before deploying. Current sessions will be used as-is."
- **AND** the script SHALL pause for 3 seconds before proceeding

## MODIFIED Requirements

### Requirement: Deployment Pre-Flight Checks
The deployment script SHALL perform comprehensive validation before deploying, including session file checks, Docker availability, and network connectivity.

**Previous Behavior**: Basic checks for Docker and network only.

**New Behavior**: Includes session file validation as a critical pre-flight check.

#### Scenario: Pre-flight checks include session validation
- **GIVEN** deployment script is executed
- **WHEN** pre-flight checks run
- **THEN** the following SHALL be validated in order:
  1. SSH connectivity to target server
  2. Docker and Docker Compose availability
  3. Existence of all required session files
  4. Postgres and Redis container health (if already running)
- **AND** if any check fails, deployment SHALL abort immediately
- **AND** the failed check name SHALL be clearly reported

## REMOVED Requirements

### Requirement: Automatic Session Onboarding During Deployment
**Reason**: Interactive login during automated deployment causes FloodWait errors and is unreliable.

**Migration**: Session creation is now a separate manual step that must be performed before deployment.

### Requirement: Database-Backed Session Initialization
**Reason**: Sessions are now file-based and do not require database initialization.

**Migration**: Remove database dependency from deployment process for session management.

