# Telegram Agent Capability - Session Management Delta

## ADDED Requirements

### Requirement: File-Based Session Storage
The Telegram agent SHALL use Telethon's file-based session storage (SQLite `.session` files) located in the `sessions/` directory instead of PostgreSQL StringSession storage.

#### Scenario: Agent initialization with file session
- **GIVEN** a valid session file exists at `sessions/{agent_name}.session`
- **WHEN** the agent initializes
- **THEN** Telethon SHALL load the session from the file
- **AND** no database query for session string SHALL occur

#### Scenario: Missing session file causes startup failure
- **GIVEN** no session file exists at `sessions/{agent_name}.session`
- **WHEN** the agent attempts to initialize
- **THEN** the agent SHALL raise a clear exception with instructions
- **AND** the exception message SHALL include the path to the missing session file
- **AND** the agent SHALL NOT attempt to request verification codes from Telegram

#### Scenario: Session file is corrupted
- **GIVEN** a corrupted session file exists at `sessions/{agent_name}.session`
- **WHEN** the agent attempts to initialize
- **THEN** Telethon SHALL raise an error
- **AND** the agent SHALL log a clear error message
- **AND** the agent SHALL NOT attempt to recover automatically

### Requirement: Session File Path Configuration
The agent SHALL accept a session file path through configuration, defaulting to `sessions/{agent_name}.session`.

#### Scenario: Custom session path via environment variable
- **GIVEN** `SOURCE_SESSION_PATH` environment variable is set to `/custom/path/my.session`
- **WHEN** the source agent initializes
- **THEN** the agent SHALL use `/custom/path/my.session` as the session file path

#### Scenario: Default session path when not configured
- **GIVEN** no custom session path is configured
- **AND** agent name is "source"
- **WHEN** the agent initializes
- **THEN** the agent SHALL use `sessions/source.session` as the session file path

### Requirement: Session Validation on Startup
The agent SHALL validate session file existence and readability during initialization before attempting Telegram connection.

#### Scenario: Pre-flight session validation success
- **GIVEN** session file exists and is readable
- **WHEN** agent performs pre-flight checks
- **THEN** validation SHALL pass
- **AND** agent SHALL proceed to Telegram connection

#### Scenario: Pre-flight session validation failure - file not found
- **GIVEN** session file does not exist
- **WHEN** agent performs pre-flight checks
- **THEN** validation SHALL fail
- **AND** agent SHALL exit with status code 1
- **AND** error message SHALL include: "Session file not found: {path}. Run 'python scripts/generate_session.py' to create a session."

#### Scenario: Pre-flight session validation failure - permission denied
- **GIVEN** session file exists but is not readable
- **WHEN** agent performs pre-flight checks
- **THEN** validation SHALL fail
- **AND** agent SHALL exit with status code 1
- **AND** error message SHALL include: "Cannot read session file: {path}. Check file permissions."

## MODIFIED Requirements

### Requirement: Session Persistence During Runtime
The agent SHALL allow Telethon to automatically persist session updates to the file system, removing the need for manual save operations.

**Previous Behavior**: Session strings were manually saved to PostgreSQL after connection.

**New Behavior**: Telethon manages session file updates automatically; no manual intervention required.

#### Scenario: Session state automatically persisted
- **GIVEN** agent is connected to Telegram
- **WHEN** session state changes (e.g., new datacenter, auth key update)
- **THEN** Telethon SHALL automatically write updates to the session file
- **AND** no explicit save call SHALL be required from the agent code

## REMOVED Requirements

### Requirement: PostgreSQL Session String Loading
**Reason**: Migrating from database-backed sessions to file-based sessions.

**Migration**: Existing sessions in PostgreSQL are deprecated. Users must ensure valid `.session` files exist in the `sessions/` directory before deployment.

### Requirement: StringSession Initialization from Database
**Reason**: File-based sessions use SQLite format directly, not StringSession.

**Migration**: Agents now pass a file path (string) to `TelegramClient` instead of a `StringSession` object.

### Requirement: Session Store Dependency
**Reason**: `SessionStore` class and its PostgreSQL backend are no longer used.

**Migration**: Remove `SessionStore` injection from agent constructors and initialization code.

