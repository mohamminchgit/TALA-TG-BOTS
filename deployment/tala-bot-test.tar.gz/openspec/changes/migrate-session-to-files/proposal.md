# Change: Migrate Telegram Sessions from PostgreSQL to File-Based Storage

## Why
تلگرام در حال حاضر کدهای تایید را برای شماره‌های ثبت‌شده ارسال نمی‌کند، که منجر به ناتوانی در لاگین مجدد می‌شود. با این حال، session‌های فعلی که از قبل ایجاد شده‌اند در فایل‌های محلی (`sessions/*.session`) موجود هستند و کار می‌کنند. مشکل این است که معماری کنونی PostgreSQL را به عنوان session store استفاده می‌کند و این session‌های محلی را نادیده می‌گیرد.

علاوه بر این، ذخیره session در PostgreSQL باعث می‌شود که session‌ها به اشتباه بین محیط‌های مختلف (local و production server) sync شوند، که منجر به خطای "Session Revoked" یا درخواست‌های مکرر کد تایید می‌شود.

این تغییر session storage را به file-based (SQLite فایلی یا StringSession) منتقل می‌کند و اطمینان می‌دهد که:
1. Session‌های معتبر موجود استفاده شوند
2. Session‌ها هیچگاه به Git push نشوند
3. Deployment process قبل از اجرای Docker Compose وجود session را بررسی کند
4. اگر session وجود نداشته باشد، پروژه بالا نیاید و کاربر مجبور به لاگین دستی شود

## What Changes
- **SessionStore**: حذف کامل `SessionStore` مبتنی بر PostgreSQL و استفاده مستقیم از فایل‌های session محلی
- **TelegramService**: تغییر برای استفاده از session فایل‌ها به جای StringSession از دیتابیس
- **Session Onboarding**: حذف یا refactor `SessionOnboarding` برای ذخیره مستقیم در فایل‌های محلی
- **Deployment Script**: اضافه کردن validation در `deploy.ps1` که قبل از `docker compose up` وجود session فایل‌ها را بررسی می‌کند
- **Docker Entrypoint**: اضافه کردن pre-flight check در `docker-entrypoint.sh` برای تایید وجود session mount شده
- **Gitignore**: اطمینان از اینکه `sessions/*.session*` در `.gitignore` قرار دارد و هیچگاه commit نمی‌شود
- **Database Migration**: حذف جدول `telethon_sessions` از PostgreSQL schema (optional cleanup)

## Impact
- **BREAKING**: Session‌های ذخیره شده در PostgreSQL دیگر استفاده نمی‌شوند
- **Migration Path**: Session‌های موجود در `sessions/` directory باید قبل از deployment validate شوند
- Affected specs:
  - `telegram-agent` - نحوه مدیریت session‌ها
  - `deployment-infrastructure` - validation و pre-flight checks
- Affected code:
  - `src/common/session_store.py` - حذف یا deprecated
  - `src/common/session_onboarding.py` - refactor یا حذف
  - `src/bot_agent/services/telegram_service.py` - تغییر session initialization
  - `deployment/deploy.ps1` - اضافه کردن session validation
  - `deployment/docker-entrypoint.sh` - اضافه کردن pre-flight check
  - `deployment/docker-compose.yml` - اطمینان از session volume mount
  - `.gitignore` - اضافه کردن session patterns

## Deployment Checklist
1. Backup current session files: `cp -r sessions/ sessions.backup/`
2. Verify all required session files exist: `ls -la sessions/`
3. Deploy with new validation script
4. Monitor logs for session validation messages
5. If deployment fails, restore from backup and investigate

