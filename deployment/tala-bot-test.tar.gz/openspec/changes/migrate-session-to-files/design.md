# Design: File-Based Session Management

## Context
در حال حاضر، سیستم از PostgreSQL برای ذخیره Telethon session strings استفاده می‌کند. این معماری مشکلات زیر را ایجاد کرده:

1. **Code Delivery Failure**: تلگرام کدهای تایید را برای شماره‌های ثبت‌شده ارسال نمی‌کند (احتماماً به دلیل FloodWait یا محدودیت API)
2. **Session Invalidation**: session‌های PostgreSQL بین local و production sync می‌شوند و invalidate می‌گردند
3. **Existing Valid Sessions Ignored**: session‌های معتبر موجود در `sessions/*.session` استفاده نمی‌شوند

Telethon به صورت native از session فایل‌های SQLite پشتیبانی می‌کند که:
- State را locally ذخیره می‌کنند
- نیاز به re-authentication ندارند مادامی که revoke نشده باشند
- می‌توانند به راحتی backup و restore شوند

## Goals / Non-Goals

### Goals
- استفاده از session فایل‌های موجود و معتبر در `sessions/` directory
- جلوگیری از commit شدن session فایل‌ها به Git
- validation قبل از deployment برای اطمینان از وجود session‌ها
- fail-fast behavior: اگر session نباشد، deployment متوقف شود
- نمایش خطاهای دقیق Telegram API برای troubleshooting

### Non-Goals
- Migration خودکار از PostgreSQL به file (کاربر باید manually session بسازد)
- Session encryption at rest (Telethon's default security is sufficient)
- Session rotation یا refresh logic (out of scope)
- Backup automation (manual backup توسط کاربر)

## Decisions

### Decision 1: استفاده از Telethon File-Based Sessions
**Choice**: استفاده از `TelegramClient(session_name, ...)` با path به فایل `.session`

**Rationale**:
- Telethon به صورت native از SQLite file sessions پشتیبانی می‌کند
- نیازی به StringSession conversion نیست
- State management توسط Telethon handle می‌شود
- کمترین تغییر در کد

**Alternatives Considered**:
1. **StringSession in Text Files**: نیاز به read/write دستی و serialize/deserialize
2. **Keep PostgreSQL**: مشکل sync و code delivery حل نمی‌شود
3. **Encrypted File Storage**: complexity اضافی بدون benefit واضح

### Decision 2: Session Validation در Deployment Script
**Choice**: `deploy.ps1` قبل از `docker compose up` وجود تمام session فایل‌های required را check می‌کند

**Implementation**:
```powershell
# Check required session files on remote server
$sessionFiles = @("source.session", "destination.session")
foreach ($file in $sessionFiles) {
    $checkCmd = "test -f ~/my-arbitrage-bot/sessions/$file && echo 'exists' || echo 'missing'"
    $result = ssh -p $Port $User@$Host $checkCmd
    if ($result -eq "missing") {
        Write-Error "Session file $file is missing on server. Run manual login first."
        exit 1
    }
}
```

**Rationale**:
- Early failure detection
- جلوگیری از اجرای containers بدون session (که باعث FloodWait می‌شود)
- پیام واضح برای کاربر

### Decision 3: حذف SessionStore و SessionOnboarding
**Choice**: حذف کامل `src/common/session_store.py` و simplify کردن `session_onboarding.py` برای تنها manual script usage

**Rationale**:
- PostgreSQL session storage دیگر استفاده نمی‌شود
- Onboarding فقط باید یکبار manually اجرا شود (نه در production runtime)
- کد ساده‌تر و کمتر abstraction

**Migration Path**:
- `scripts/generate_session.py` را update کن که مستقیم در `sessions/` بنویسد
- کاربران باید manually session بسازند با این script

### Decision 4: Docker Volume Mount Strategy
**Choice**: bind mount `sessions/` directory از host به container به صورت read-only

**docker-compose.yml**:
```yaml
services:
  agent-source:
    volumes:
      - ./sessions:/app/sessions:ro  # Read-only mount
```

**Rationale**:
- Session فایل‌ها فقط روی host ساخته می‌شوند
- Container نمی‌تواند session‌ها را modify یا delete کند
- Safer deployment

### Decision 5: Gitignore Strategy
**Choice**: اضافه کردن pattern‌های زیر به `.gitignore`:
```
sessions/*.session
sessions/*.session-journal
```

**Rationale**:
- جلوگیری از accidental commit
- session‌ها sensitive هستند و نباید share شوند
- هر environment session‌های خودش را دارد

## Risks / Trade-offs

### Risk 1: Session Loss
**Mitigation**:
- راهنمای backup در documentation
- warning در deployment script برای backup قبل از deploy
- script برای manual session generation

### Risk 2: Manual Session Setup Overhead
**Trade-off**: کاربر باید manually یکبار session بسازد، اما این:
- از FloodWait جلوگیری می‌کند
- session‌های معتبر موجود را استفاده می‌کند
- deployment را سریعتر و safe‌تر می‌کند

### Risk 3: Session Revocation
اگر تلگرام session را revoke کند، کاربر باید manually دوباره login کند.

**Mitigation**:
- خطای واضح در logs
- راهنمای troubleshooting در docs
- script آماده برای regeneration

## Migration Plan

### Phase 1: Code Changes (این PR)
1. Remove PostgreSQL session dependencies
2. Update `TelegramService` to use file paths
3. Update `generate_session.py` to write to files
4. Add validation to deployment scripts

### Phase 2: Deployment
1. Verify existing session files: `ls -la sessions/`
2. Backup: `cp -r sessions/ sessions.backup/`
3. Run deployment with new script
4. Monitor logs for session loading

### Phase 3: Cleanup (Optional)
1. Drop `telethon_sessions` table from PostgreSQL
2. Remove unused session_store.py
3. Update documentation

### Rollback Plan
اگر deployment fail شد:
1. Restore previous deployment
2. Restore session files از backup
3. Re-deploy old version

## Open Questions
- ❓ آیا admin bot هم session فایل دارد یا فقط source/destination؟
- ❓ آیا باید script برای migration از PostgreSQL به file بنویسیم؟ (فعلاً فرض: خیر، manual)
- ❓ چگونه session files را بین development و production sync کنیم؟ (فعلاً فرض: هیچگاه sync نکن)

