# Implementation Tasks: Migrate Sessions to Files

## 1. Preparation & Validation
- [ ] 1.1 Verify existing session files in `sessions/` directory are valid
- [ ] 1.2 Create backup of existing session files: `cp -r sessions/ sessions.backup/`
- [ ] 1.3 Test existing sessions by running agents locally with file-based sessions
- [ ] 1.4 Document session file locations and their purposes

## 2. Code Refactoring
- [ ] 2.1 Update `src/bot_agent/services/telegram_service.py` to use file path instead of StringSession
- [ ] 2.2 Update `src/bot_agent/agent.py` to remove `SessionStore` dependency
- [ ] 2.3 Update `src/config/settings.py` to add `session_path` configuration option
- [ ] 2.4 Update `main.py` to remove `ensure-sessions` command and database-backed onboarding
- [ ] 2.5 Simplify or remove `src/common/session_onboarding.py` (keep only for scripts)
- [ ] 2.6 Deprecate or remove `src/common/session_store.py`

## 3. Script Updates
- [ ] 3.1 Update `scripts/generate_session.py` to save directly to `sessions/*.session` files
- [ ] 3.2 Add session validation script: `scripts/validate_sessions.py`
- [ ] 3.3 Update `scripts/store_session.py` or mark as deprecated
- [ ] 3.4 Test all scripts to ensure they work with file-based sessions

## 4. Deployment Infrastructure
- [ ] 4.1 Create or update `.gitignore` with `sessions/*.session` and `sessions/*.session-journal`
- [ ] 4.2 Update `deployment/docker-compose.yml` to mount `sessions/` as read-only volume
- [ ] 4.3 Add session validation function to `deployment/deploy.ps1`
- [ ] 4.4 Add pre-flight session check to `deployment/docker-entrypoint.sh`
- [ ] 4.5 Add backup reminder message to deployment script
- [ ] 4.6 Test deployment script validation logic with missing sessions

## 5. Database Cleanup (Optional)
- [ ] 5.1 Create migration script to drop `telethon_sessions` table from PostgreSQL
- [ ] 5.2 Update `src/common/db.py` to remove session-related migrations
- [ ] 5.3 Verify no code references to `telethon_sessions` table remain

## 6. Documentation
- [ ] 6.1 Update `docs/operations_runbook.md` with file-based session instructions
- [ ] 6.2 Add troubleshooting section for session file issues
- [ ] 6.3 Document backup and restore procedures for session files
- [ ] 6.4 Update deployment documentation with session validation steps

## 7. Testing & Validation
- [ ] 7.1 Test agent startup with valid session files
- [ ] 7.2 Test agent startup with missing session files (should fail gracefully)
- [ ] 7.3 Test deployment script with all sessions present
- [ ] 7.4 Test deployment script with missing sessions (should abort)
- [ ] 7.5 Test Docker entrypoint pre-flight checks
- [ ] 7.6 Verify sessions are not committed to Git
- [ ] 7.7 Test session persistence after container restart

## 8. Deployment
- [ ] 8.1 Deploy to staging/test environment first
- [ ] 8.2 Verify all agents connect successfully with file-based sessions
- [ ] 8.3 Monitor logs for any session-related errors
- [ ] 8.4 Deploy to production with validated session files
- [ ] 8.5 Confirm all services are running and healthy

## Success Criteria
- ✅ Agents use session files from `sessions/` directory
- ✅ Session files are excluded from Git commits
- ✅ Deployment script validates session files before `docker compose up`
- ✅ Container entrypoint validates sessions before starting processes
- ✅ Missing sessions cause clear error messages, not FloodWait
- ✅ No code references to PostgreSQL session storage remain
- ✅ Documentation is updated with new procedures

