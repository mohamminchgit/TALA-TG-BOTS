param (
    [string]$targetHost = $env:TALATG_DEPLOY_HOST,
    [string]$User = $env:TALATG_DEPLOY_USER,
    [string]$RemotePath = $env:TALATG_DEPLOY_PATH
)

if (-not $targetHost) { throw "Set TALATG_DEPLOY_HOST or pass -targetHost." }
if (-not $User) { throw "Set TALATG_DEPLOY_USER or pass -User." }
if (-not $RemotePath) { throw "Set TALATG_DEPLOY_PATH or pass -RemotePath." }

if (-not (Get-Command ssh -ErrorAction SilentlyContinue)) { throw "ssh not found in PATH." }
if (-not (Get-Command scp -ErrorAction SilentlyContinue)) { throw "scp not found in PATH." }
if (-not (Get-Command tar -ErrorAction SilentlyContinue)) { throw "tar not found in PATH." }

$root = Resolve-Path (Join-Path $PSScriptRoot "..")
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$archiveName = "tala-bot-$timestamp.tar.gz"
$archivePath = Join-Path $PSScriptRoot $archiveName

$localEnvFile = Join-Path $root ".env"
$localSessionsDir = Join-Path $root "sessions"

# Validate local session files exist
Write-Host "⏳ Checking local session files..." -ForegroundColor Cyan
$requiredSessions = @("source.session", "destination.session")
$missingLocally = @()

foreach ($sessionFile in $requiredSessions) {
    $sessionPath = Join-Path $localSessionsDir $sessionFile
    if (-not (Test-Path $sessionPath)) {
        $missingLocally += $sessionFile
    }
}

if ($missingLocally.Count -gt 0) {
    Write-Host "❌ Missing local session files: $($missingLocally -join ', ')" -ForegroundColor Red
    Write-Host "   Run 'python scripts/generate_session.py' to create sessions." -ForegroundColor Yellow
    throw "Session validation failed. Deployment aborted."
}

Write-Host "✅ All required session files found locally." -ForegroundColor Green

# Reminder to backup
Write-Host ""
Write-Host "⚠️  REMINDER: Ensure session files are backed up before deploying." -ForegroundColor Yellow
Write-Host "   Current sessions will be uploaded to the server." -ForegroundColor Yellow
Start-Sleep -Seconds 3

Push-Location $root
try {
    $tarArgs = @(
        "czf", $archivePath,
        "--exclude=.git",
        "--exclude=data",
        "--exclude=ssh-mcp",
        "--exclude=*.tar.gz",
        "sessions",
        "."
    )
    
    & tar @tarArgs
    
    # If .env exists, we need to handle it separately since Windows tar doesn't support --transform
    # For now, we'll rely on merge-env.sh on the server side
}
finally {
    Pop-Location
}

& scp $archivePath "$User@${targetHost}:/tmp/$archiveName"

# دستورات ریموت که شامل validation و اجرای merge-env.sh هم می‌شود
$remoteCommand = @"
mkdir -p $RemotePath && \
tar -xzf /tmp/$archiveName -C $RemotePath --strip-components=1 && \
cd $RemotePath && \
bash deployment/merge-env.sh . && \
python3 -m pip install --user -r requirements.txt && \
echo '⏳ Validating session files on server...' && \
if [ ! -f sessions/source.session ] || [ ! -f sessions/destination.session ]; then \
  echo '❌ Session files missing on server!' && \
  exit 1; \
fi && \
echo '✅ Session files validated successfully.' && \
ls -lh sessions/*.session && \
docker compose -f deployment/docker-compose.yml pull postgres redis || true && \
docker compose -f deployment/docker-compose.yml up -d postgres redis && \
docker compose -f deployment/docker-compose.yml up -d --build && \
rm /tmp/$archiveName
"@
& ssh -t "$User@$targetHost" $remoteCommand

Remove-Item $archivePath -Force