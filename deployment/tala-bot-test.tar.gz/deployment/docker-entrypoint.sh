#!/usr/bin/env bash
set -euo pipefail

# Pre-flight check: Validate session files exist
echo "🔍 Validating session files..."
REQUIRED_SESSIONS=("sessions/source.session" "sessions/destination.session")
MISSING=()

for session_file in "${REQUIRED_SESSIONS[@]}"; do
	if [ ! -f "$session_file" ]; then
		MISSING+=("$session_file")
	fi
done

if [ ${#MISSING[@]} -gt 0 ]; then
	echo "❌ Missing session files: ${MISSING[*]}"
	echo "   Ensure session files are mounted at /app/sessions/"
	exit 1
fi

echo "✅ Session files validated successfully."
ls -lh sessions/*.session

RUN_MODE="${RUN_MODE:-all}"

if [ "$RUN_MODE" = "engine" ]; then
	exec python main.py engine
elif [ "$RUN_MODE" = "agents" ]; then
	exec python main.py run
elif [ "$RUN_MODE" = "all" ]; then
	python main.py engine &
	ENGINE_PID=$!
	python main.py run &
	AGENTS_PID=$!

	terminate() {
		kill -TERM "$ENGINE_PID" "$AGENTS_PID" 2>/dev/null || true
	}

	trap terminate SIGTERM SIGINT

	wait -n || true
	terminate
	wait
else
	echo "Unknown RUN_MODE: $RUN_MODE"
	exit 1
fi

