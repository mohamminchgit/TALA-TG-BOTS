from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Awaitable, Callable, Optional

from telethon import TelegramClient, events
from telethon.errors import SessionPasswordNeededError

logger = logging.getLogger(__name__)


class TelegramService:
    """Wrapper around Telethon client with convenience helpers."""

    def __init__(self, session_path: str, api_id: int, api_hash: str) -> None:
        self._session_path = session_path
        self._validate_session_file()
        self._client = TelegramClient(self._session_path, api_id, api_hash)

    def _validate_session_file(self) -> None:
        """Validate that session file exists and is readable before attempting connection."""
        session_file = Path(self._session_path)
        
        if not session_file.exists():
            raise FileNotFoundError(
                f"Session file not found: {self._session_path}\n"
                f"Run 'python scripts/generate_session.py' to create a session."
            )
        
        if not os.access(session_file, os.R_OK):
            raise PermissionError(
                f"Cannot read session file: {self._session_path}\n"
                f"Check file permissions."
            )
        
        logger.info("Session file validated: %s (size: %d bytes)", self._session_path, session_file.stat().st_size)

    @property
    def client(self) -> TelegramClient:
        return self._client

    async def connect(self, phone_number: Optional[str], phone_password: Optional[str]) -> None:
        await self._client.connect()
        if await self._client.is_user_authorized():
            logger.info("Telethon session loaded successfully from %s", self._session_path)
            return

        if not phone_number:
            raise RuntimeError(
                f"Session at {self._session_path} is not authorized and no phone number provided.\n"
                f"Delete the session file and run 'python scripts/generate_session.py' to create a new one."
            )

        logger.info("Authorizing Telegram session for %s", phone_number)
        try:
            await self._client.start(phone=phone_number, password=phone_password)
        except SessionPasswordNeededError:
            raise RuntimeError(
                "Two-factor authentication is enabled but SOURCE_PHONE_PASSWORD/DESTINATION_PHONE_PASSWORD "
                "is not configured. Provide the password or generate the session manually."
            ) from None
        logger.info("Session authorized and persisted to %s", self._session_path)

    async def run_until_disconnected(self) -> None:
        await self._client.run_until_disconnected()

    def add_message_handler(
        self,
        handler: Callable[[events.NewMessage.Event], Awaitable[None]],
        chats: Optional[list[int | str]] = None,
    ) -> None:
        chats = chats or []

        @self._client.on(events.NewMessage(chats=chats or None))
        async def wrapped(event: events.NewMessage.Event) -> None:  # type: ignore[misc]
            await handler(event)

        logger.debug("Registered new message handler for chats: %s", chats if chats else "all")

    def add_deleted_handler(
        self,
        handler: Callable[[events.MessageDeleted.Event], Awaitable[None]],
        chats: Optional[list[int | str]] = None,
    ) -> None:
        chats = chats or []

        @self._client.on(events.MessageDeleted(chats=chats or None))
        async def wrapped(event: events.MessageDeleted.Event) -> None:  # type: ignore[misc]
            await handler(event)

        logger.debug("Registered message deleted handler for chats: %s", chats if chats else "all")
